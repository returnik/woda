package com.example.myapplication;

public class Napoj {
    String nazwa;
    Boolean czygazowany;
    String smak;

    public Napoj(String smak, String nazwa, Boolean czygazowany) {
        this.smak = smak;
        this.nazwa = nazwa;
        this.czygazowany = czygazowany;
    }

    @Override
    public String toString() {
        return
                 nazwa + '\n' +
                "czy gazowany = " + (czygazowany? "tak" : "nie" ) + '\n' + smak + '\n'
                ;
    }
}
