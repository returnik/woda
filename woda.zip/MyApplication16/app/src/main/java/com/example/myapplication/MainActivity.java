package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button button;
    Button button1;
    ListView listView;
    Spinner spinner;
    EditText editText;
    CheckBox checkBox;

    ArrayList<Napoj>arrayListnapoje;
    ArrayAdapter<Napoj>arrayAdapternapoje;

    Napoj wybranynapoj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        button1 = findViewById(R.id.button1);
        spinner = findViewById(R.id.spinner);
        editText = findViewById(R.id.editTextText);
        checkBox = findViewById(R.id.checkBox);
        listView = findViewById(R.id.lista);

        Napoj napoj = new Napoj("Cytrynowy","Zbyszko 3 cytryny",true);
        arrayListnapoje = new ArrayList<>();
        arrayListnapoje.add(napoj);
        arrayAdapternapoje = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1,arrayListnapoje);
        listView.setAdapter(arrayAdapternapoje);

        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String nazwa = editText.getText().toString();
                        Boolean czygazowane = checkBox.isChecked();
                        String typ = spinner.getSelectedItem().toString();
                        Napoj napoj1 = new Napoj(typ,nazwa,czygazowane);
                        arrayListnapoje.add(napoj1);
                        arrayAdapternapoje.notifyDataSetChanged();

                    }
                }


        );
        listView.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                        arrayListnapoje.remove(i);
                        arrayAdapternapoje.notifyDataSetChanged();
                        return false;
                    }
                }
        );
        listView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        wybranynapoj = arrayListnapoje.get(i);
                        editText.setText(wybranynapoj.nazwa);
                        checkBox.setChecked(wybranynapoj.czygazowany);


                    }
                }
        );
        button1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        wybranynapoj.nazwa=editText.getText().toString();
                        wybranynapoj.czygazowany=checkBox.isChecked();
                        wybranynapoj.smak=spinner.getSelectedItem().toString();
                        arrayAdapternapoje.notifyDataSetChanged();
                    }
                }
        );
    }

}